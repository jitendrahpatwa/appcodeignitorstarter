<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title; ?></title>
</head>
<body>
<h1><b><i><?php echo $heading; ?></i></b></h1><br>
<p><?php echo $message; ?></p>
</body>
</html>