<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
<?php echo $header; ?>
<form>
	<input type="text" name="name" placeholder="enter name">
	<input type="password" name="age" placeholder="enter age">
	<input type="submit" value="Take a look">
</form>
</body>
</html>